package com.finmate.ui.friend

enum class FriendCacheStatus {
    ONLINE,
    OFFLINE
}

