package com.finmate.data.repository.model;

public enum BudgetPeriod {
    WEEK,
    MONTH
}

