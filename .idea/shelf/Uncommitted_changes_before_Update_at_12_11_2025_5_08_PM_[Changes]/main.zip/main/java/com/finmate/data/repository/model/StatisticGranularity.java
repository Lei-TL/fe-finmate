package com.finmate.data.repository.model;

public enum StatisticGranularity {
    DAY,
    WEEK,
    MONTH
}

