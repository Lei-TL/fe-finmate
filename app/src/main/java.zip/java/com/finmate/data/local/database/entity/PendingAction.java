package com.finmate.data.local.database.entity;

public final class PendingAction {
    public static final String NONE = "NONE";
    public static final String CREATE = "CREATE";
    public static final String UPDATE = "UPDATE";
    public static final String DELETE = "DELETE";
}
