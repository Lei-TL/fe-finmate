package com.finmate.ui.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.finmate.R;

public class NotificationSettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);
    }
}
